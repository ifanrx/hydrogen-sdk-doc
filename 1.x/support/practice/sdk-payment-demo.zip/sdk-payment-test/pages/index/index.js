Page({
  pay: function () {
    let params = {
      totalCost: 0.1,
      merchandiseDescription: '一条支付描述'
    }

    wx.BaaS.pay(params).then(res => {
      console.log('pay')
    }, err => {
      // 未完成用户授权或发生网络异常等
      console.log(err)
    })
  }
})
