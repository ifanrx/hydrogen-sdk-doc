//app.js
App({
  onLaunch: function () {
    require('./vendor/sdk-v1.1.6.js')
    let clientID = ''
    wx.BaaS.init(clientID)

    wx.BaaS.login()
  }
})